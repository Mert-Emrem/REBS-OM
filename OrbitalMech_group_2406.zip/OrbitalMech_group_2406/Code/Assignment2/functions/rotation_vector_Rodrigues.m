function [v_rot] = rotation_vector_Rodrigues(vector, direction, delta)
% ------------------------------------------------
% [v_rot] = rotation_vector_Rodrigues(vector, direction, delta)
% 
% this function rotates a vector
% 
% INPUTS
% vector      [3X1]     vector to be rotated
% direction   [3x1]     direction around which you want the rotation
% delta       [1X1]     angle of rotation
%   
% OUTPUTS:
% v_rot       [3x1]     rotated vector
% 
% Authors: Serlini Mariagiulia, Bernasconi Ludovico, Emrem Mert, Richero
%         Giovanni
% Last update: 7/1/2025
%
%---------------------------------------------------------------------
v = vector;
u = direction;

v_rot = v*cos(delta) + cross(u, v)*sin(delta) + u.*dot(u, v).*(1-cos(delta));

end